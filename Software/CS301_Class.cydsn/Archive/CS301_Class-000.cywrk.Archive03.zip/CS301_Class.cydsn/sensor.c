/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/



#include <project.h>
#include "sensor.h"

// These number is based on Ross's experiement.
#define T_PKPK    737      // 0.9 V 
#define T_HYST     98      // 0.12 V, gap/4
#define T_HIGH   (T_PKPK + T_HYST)
#define T_LOW    (T_PKPK - T_HYST)
#define N_SAMPLES  20

static volatile uint16 Vmax[N_SENSORS];
static volatile uint16 Vmin[N_SENSORS];
static volatile uint16 Vpp[N_SENSORS];
static volatile uint8 sampleCount;
static volatile uint8 windowDone;



CY_ISR_PROTO(eocHandler);
CY_ISR(eocHandler){
    uint8 i;
    
    for (i = 0; i < N_SENSORS; i++) {
    int16 v = ADC_Sensor_GetResult16(i);   
    if (v < 0) v = 0;
    if (v > vmax[i]) vmax[i] = v;
    if (v < vmin[i]) vmin[i] = v;
    }

}


void sensor_init(void) {
    ADC_Sensor_Start();
    isr_eoc_StartEx(eocHandler);
}


uint8 isSensorOnWhite(uint8 sensor_th){

}

/* [] END OF FILE */